// Main Application Controller
const AppController = {
  init() {
    this.setupEventListeners();
    this.initializeComponents();
  },

  setupEventListeners() {
    // Keyboard shortcuts
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        const panel = document.getElementById('customPanel');
        if (panel.classList.contains('open')) {
          this.togglePanel();
        }
      }
    });

    // Click outside to close panel
    document.addEventListener('click', (event) => {
      const panel = document.getElementById('customPanel');
      const panelToggle = document.querySelector('.panel-toggle');
      
      if (panel.classList.contains('open') && 
          !panel.contains(event.target) && 
          event.target !== panelToggle && 
          !panelToggle.contains(event.target)) {
        this.togglePanel();
      }
    });

    // Touch swipe support for mobile
    let touchStartX = 0;
    let touchEndX = 0;

    document.addEventListener('touchstart', (event) => {
      touchStartX = event.changedTouches[0].screenX;
    });

    document.addEventListener('touchend', (event) => {
      touchEndX = event.changedTouches[0].screenX;
      this.handleSwipe(touchStartX, touchEndX);
    });
  },

  initializeComponents() {
    ClockController.init();
    CalendarController.init();
    SliderController.init();
    ThemeController.init();
  },

  togglePanel() {
    const panel = document.getElementById('customPanel');
    panel.classList.toggle('open');
    
    // Update ARIA attributes for accessibility
    const isOpen = panel.classList.contains('open');
    panel.setAttribute('aria-hidden', !isOpen);
    
    if (isOpen) {
      panel.focus();
    }
  },

  handleSwipe(startX, endX) {
    const panel = document.getElementById('customPanel');
    const swipeThreshold = 50;

    // Right to left swipe (close panel)
    if (panel.classList.contains('open') && startX - endX > swipeThreshold) {
      this.togglePanel();
    }

    // Left to right swipe (open panel)
    if (!panel.classList.contains('open') && endX - startX > swipeThreshold && startX < 50) {
      this.togglePanel();
    }
  }
};

// Notification/Toast Controller
const NotificationController = {
  container: null,

  init() {
    this.container = document.getElementById('toastContainer');
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.id = 'toastContainer';
      this.container.className = 'toast-container';
      this.container.setAttribute('aria-live', 'polite');
      document.body.appendChild(this.container);
    }
  },

  show(message, type = 'info', duration = 5000) {
    if (!this.container) this.init();

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
      <div>${this.escapeHtml(message)}</div>
      <span class="toast-close" onclick="this.parentElement.remove()" aria-label="Close notification">&times;</span>
    `;

    this.container.appendChild(toast);

    // Show toast with animation
    requestAnimationFrame(() => {
      toast.classList.add('show');
    });

    // Auto remove
    if (duration > 0) {
      setTimeout(() => {
        this.hide(toast);
      }, duration);
    }

    return toast;
  },

  hide(toast) {
    if (toast && toast.parentElement) {
      toast.classList.remove('show');
      setTimeout(() => {
        if (toast.parentElement) {
          toast.parentElement.removeChild(toast);
        }
      }, 300);
    }
  },

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
};

// Tab Controller
const TabController = {
  open(event, tabId) {
    // Hide all tab panes
    document.querySelectorAll('.tab-pane').forEach(pane => {
      pane.style.display = 'none';
      pane.setAttribute('aria-hidden', 'true');
    });

    // Remove active class from all tab links
    document.querySelectorAll('.tab-link').forEach(link => {
      link.classList.remove('active');
      link.setAttribute('aria-selected', 'false');
      link.setAttribute('tabindex', '-1');
    });

    // Show selected tab pane
    const selectedPane = document.getElementById(tabId);
    if (selectedPane) {
      selectedPane.style.display = 'block';
      selectedPane.setAttribute('aria-hidden', 'false');
    }

    // Add active class to clicked tab
    if (event.currentTarget) {
      event.currentTarget.classList.add('active');
      event.currentTarget.setAttribute('aria-selected', 'true');
      event.currentTarget.setAttribute('tabindex', '0');
    }
  }
};

// Navigation Controller
const NavigationController = {
  setActive(item) {
    document.querySelectorAll('.nav-item').forEach(navItem => {
      navItem.classList.remove('active');
      navItem.setAttribute('aria-current', 'false');
    });
    
    item.classList.add('active');
    item.setAttribute('aria-current', 'page');
    
    NotificationController.show(`Navigating to ${item.textContent}`, 'info');
  }
};

// Clock Controller
const ClockController = {
  type: 'digital',
  canvas: null,
  ctx: null,

  init() {
    this.canvas = document.getElementById('analog-clock');
    if (this.canvas) {
      this.ctx = this.canvas.getContext('2d');
    }
    
    this.updateClock();
    setInterval(() => this.updateClock(), 1000);
  },

  setType(type) {
    this.type = type;

    // Update toggle buttons
    document.getElementById('digitalToggle').classList.toggle('active', type === 'digital');
    document.getElementById('analogToggle').classList.toggle('active', type === 'analog');

    // Show/hide displays
    const analogContainer = document.getElementById('analog-clock-container');
    const digitalClock = document.getElementById('clock');

    if (type === 'digital') {
      analogContainer.style.display = 'none';
      digitalClock.style.display = 'block';
    } else {
      analogContainer.style.display = 'flex';
      digitalClock.style.display = 'none';
      this.drawAnalogClock();
    }
  },

  updateClock() {
    const now = new Date();

    if (this.type === 'digital') {
      const timeString = now.toLocaleTimeString();
      const clockElement = document.getElementById('clock');
      if (clockElement) {
        clockElement.textContent = timeString;
      }
    } else {
      this.drawAnalogClock();
    }

    // Update date
    const dateString = now.toLocaleDateString(undefined, {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    
    const dateElement = document.getElementById('date');
    if (dateElement) {
      dateElement.textContent = dateString;
    }
  },

  drawAnalogClock() {
    if (!this.canvas || !this.ctx) return;

    const radius = this.canvas.height / 2;
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    // Get CSS custom properties
    const styles = getComputedStyle(document.documentElement);
    const cardBg = styles.getPropertyValue('--card-bg').trim();
    const primary = styles.getPropertyValue('--primary').trim();
    const dark = styles.getPropertyValue('--dark').trim();
    const warning = styles.getPropertyValue('--warning').trim();

    // Draw clock face
    this.ctx.beginPath();
    this.ctx.arc(radius, radius, radius * 0.9, 0, 2 * Math.PI);
    this.ctx.fillStyle = cardBg || '#ffffff';
    this.ctx.fill();

    // Draw border
    this.ctx.beginPath();
    this.ctx.arc(radius, radius, radius * 0.9, 0, 2 * Math.PI);
    this.ctx.strokeStyle = primary || '#4361ee';
    this.ctx.lineWidth = radius * 0.05;
    this.ctx.stroke();

    // Draw hour markers
    for (let i = 0; i < 12; i++) {
      const angle = (i * Math.PI) / 6;
      this.ctx.beginPath();
      const innerRadius = radius * 0.8;
      const outerRadius = radius * 0.9;
      
      this.ctx.moveTo(
        radius + innerRadius * Math.sin(angle),
        radius - innerRadius * Math.cos(angle)
      );
      this.ctx.lineTo(
        radius + outerRadius * Math.sin(angle),
        radius - outerRadius * Math.cos(angle)
      );
      
      this.ctx.lineWidth = radius * 0.02;
      this.ctx.strokeStyle = dark || '#212529';
      this.ctx.stroke();
    }

    // Draw center point
    this.ctx.beginPath();
    this.ctx.arc(radius, radius, radius * 0.05, 0, 2 * Math.PI);
    this.ctx.fillStyle = primary || '#4361ee';
    this.ctx.fill();

    // Get current time
    const now = new Date();
    const hour = now.getHours() % 12;
    const minute = now.getMinutes();
    const second = now.getSeconds();

    // Draw hands
    const hourAngle = ((hour + minute / 60) * Math.PI) / 6;
    this.drawHand(hourAngle, radius * 0.5, radius * 0.05, dark);

    const minuteAngle = ((minute + second / 60) * Math.PI) / 30;
    this.drawHand(minuteAngle, radius * 0.7, radius * 0.04, dark);

    const secondAngle = (second * Math.PI) / 30;
    this.drawHand(secondAngle, radius * 0.8, radius * 0.01, warning);
  },

  drawHand(angle, length, width, color) {
    const radius = this.canvas.height / 2;
    this.ctx.beginPath();
    this.ctx.moveTo(radius, radius);
    this.ctx.lineTo(
      radius + length * Math.sin(angle),
      radius - length * Math.cos(angle)
    );
    this.ctx.lineWidth = width;
    this.ctx.strokeStyle = color || '#212529';
    this.ctx.stroke();
  }
};

// Calendar Controller
const CalendarController = {
  init() {
    this.generate();
  },

  generate() {
    const now = new Date();
    const month = now.getMonth();
    const year = now.getFullYear();
    const currentDay = now.getDate();

    // Set month name
    const monthName = now.toLocaleString('default', { month: 'long' });
    const monthElement = document.getElementById('current-month');
    if (monthElement) {
      monthElement.textContent = `${monthName} ${year}`;
    }

    const calendarElement = document.getElementById('mini-calendar');
    if (!calendarElement) return;

    calendarElement.innerHTML = '';

    // Add day names
    const dayNames = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
    dayNames.forEach(day => {
      const dayElement = document.createElement('div');
      dayElement.className = 'calendar-day day-name';
      dayElement.textContent = day;
      dayElement.setAttribute('role', 'columnheader');
      calendarElement.appendChild(dayElement);
    });

    // Calculate calendar data
    const firstDay = new Date(year, month, 1).getDay();
    const totalDays = new Date(year, month + 1, 0).getDate();

    // Add empty spaces
    for (let i = 0; i < firstDay; i++) {
      const emptyDay = document.createElement('div');
      emptyDay.className = 'calendar-day empty';
      emptyDay.setAttribute('role', 'gridcell');
      calendarElement.appendChild(emptyDay);
    }

    // Add days
    for (let day = 1; day <= totalDays; day++) {
      const dayElement = document.createElement('div');
      dayElement.className = 'calendar-day';
      dayElement.textContent = day;
      dayElement.setAttribute('role', 'gridcell');

      if (day === currentDay) {
        dayElement.classList.add('current');
        dayElement.setAttribute('aria-current', 'date');
      }

      calendarElement.appendChild(dayElement);
    }
  }
};

// Mood Controller
const MoodController = {
  responses: {
    '😄': 'Great to see you happy today!',
    '🙂': 'Looking good! Have a nice day.',
    '😐': 'Hope your day gets better soon.',
    '😢': 'Sorry you\'re feeling down.',
    '😤': 'Take a deep breath, things will improve.'
  },

  track(emoji) {
    const responseElement = document.getElementById('mood-response');
    if (responseElement) {
      responseElement.textContent = this.responses[emoji] || 'Mood tracked!';
    }
    
    NotificationController.show(`Mood set to ${emoji}`, 'success');
    
    // Store mood data (could be extended to use localStorage in a real app)
    this.saveMoodData(emoji);
  },

  saveMoodData(emoji) {
    // In a real application, this would save to a database or localStorage
    console.log(`Mood logged: ${emoji} at ${new Date().toISOString()}`);
  }
};

// Chip Controller
const ChipController = {
  toggle(chip) {
    chip.classList.toggle('active');
    const isActive = chip.classList.contains('active');
    
    // Update ARIA attributes
    chip.setAttribute('aria-pressed', isActive);
    
    const chipText = chip.textContent.replace('×', '').trim();
    NotificationController.show(
      `Chip ${isActive ? 'activated' : 'deactivated'}: ${chipText}`,
      isActive ? 'success' : 'info'
    );
  },

  remove(event, chip) {
    event.stopPropagation();
    const chipText = chip.textContent.replace('×', '').trim();
    
    chip.style.transform = 'scale(0)';
    chip.style.opacity = '0';
    
    setTimeout(() => {
      if (chip.parentElement) {
        chip.parentElement.removeChild(chip);
      }
    }, 300);
    
    NotificationController.show(`Chip removed: ${chipText}`, 'info');
  }
};

// Slider Controller
const SliderController = {
  init() {
    const sliders = document.querySelectorAll('.slider');
    sliders.forEach(slider => {
      this.updateDisplay(slider);
      slider.addEventListener('input', () => this.updateDisplay(slider));
    });
  },

  updateDisplay(slider) {
    const valueDisplay = slider.nextElementSibling;
    if (valueDisplay && valueDisplay.classList.contains('slider-value')) {
      const unit = slider.id.includes('fontSize') || slider.id.includes('borderRadius') ? 'px' : '%';
      valueDisplay.textContent = slider.value + unit;
    }
    
    // Handle special sliders
    if (slider.id === 'opacity') {
      this.updateOpacity(slider.value);
    }
  },

  updateOpacity(value) {
    document.querySelectorAll('.section').forEach(section => {
      section.style.opacity = value / 100;
    });
  }
};

// Theme Controller
const ThemeController = {
  init() {
    // Set initial active color option
    const defaultOption = document.querySelector('.color-option[style*="#4361ee"]');
    if (defaultOption) {
      defaultOption.classList.add('active');
    }
  },

  changeColor(variable, color) {
    document.documentElement.style.setProperty(`--${variable}`, color);

    // Update active color indicator
    document.querySelectorAll('.color-option').forEach(option => {
      option.classList.remove('active');
    });
    
    event.target.classList.add('active');
    NotificationController.show(`Color changed to ${color}`, 'success');
  },

  changeTheme(theme) {
    const themes = {
      dark: {
        primary: '#7b68ee',
        secondary: '#4cc9f0',
        light: '#2d3748',
        dark: '#f8f9fa',
        bodyBg: '#121212',
        cardBg: '#1e1e1e',
        textColor: '#e2e8f0',
        borderColor: '#4a5568'
      },
      blue: {
        primary: '#0077b6',
        secondary: '#00b4d8',
        light: '#caf0f8',
        dark: '#03045e',
        bodyBg: '#f5f7ff',
        cardBg: '#ffffff',
        textColor: '#212529',
        borderColor: '#e9ecef'
      },
      green: {
        primary: '#2a9d8f',
        secondary: '#e9c46a',
        light: '#e9f5db',
        dark: '#264653',
        bodyBg: '#f5f7ff',
        cardBg: '#ffffff',
        textColor: '#212529',
        borderColor: '#e9ecef'
      },
      light: {
        primary: '#4361ee',
        secondary: '#3a0ca3',
        light: '#f8f9fa',
        dark: '#212529',
        bodyBg: '#f5f7ff',
        cardBg: '#ffffff',
        textColor: '#212529',
        borderColor: '#e9ecef'
      }
    };

    const selectedTheme = themes[theme] || themes.light;

    // Apply theme variables
    Object.entries(selectedTheme).forEach(([key, value]) => {
      const cssVar = key.replace(/([A-Z])/g, '-$1').toLowerCase();
      document.documentElement.style.setProperty(`--${cssVar}`, value);
    });

    // Apply theme class
    document.body.classList.toggle('dark-theme', theme === 'dark');
    
    NotificationController.show(`Theme changed to ${theme}`, 'success');
  },

  changeFontSize(size) {
    document.documentElement.style.fontSize = size + 'px';
    const valueElement = document.getElementById('fontSizeValue');
    if (valueElement) {
      valueElement.textContent = size + 'px';
    }
  },

  changeBorderRadius(radius) {
    document.documentElement.style.setProperty('--border-radius', radius + 'px');
    const valueElement = document.getElementById('borderRadiusValue');
    if (valueElement) {
      valueElement.textContent = radius + 'px';
    }

    // Apply to elements with border-radius
    document.querySelectorAll('*').forEach(el => {
      const computedStyle = window.getComputedStyle(el);
      if (computedStyle.borderRadius && computedStyle.borderRadius !== '0px') {
        el.style.borderRadius = radius + 'px';
      }
    });
  },

  resetStyles() {
    // Reset CSS variables
    const defaults = {
      '--primary': '#4361ee',
      '--secondary': '#3a0ca3',
      '--light': '#f8f9fa',
      '--dark': '#212529',
      '--body-bg': '#f5f7ff',
      '--card-bg': '#ffffff',
      '--text-color': '#212529',
      '--border-color': '#e9ecef'
    };

    Object.entries(defaults).forEach(([prop, value]) => {
      document.documentElement.style.setProperty(prop, value);
    });

    // Remove dark theme
    document.body.classList.remove('dark-theme');

    // Reset controls
    document.documentElement.style.fontSize = '16px';
    const fontSizeSlider = document.getElementById('fontSize');
    const fontSizeValue = document.getElementById('fontSizeValue');
    if (fontSizeSlider) fontSizeSlider.value = '16';
    if (fontSizeValue) fontSizeValue.textContent = '16px';

    const borderRadiusSlider = document.getElementById('borderRadius');
    const borderRadiusValue = document.getElementById('borderRadiusValue');
    if (borderRadiusSlider) borderRadiusSlider.value = '5';
    if (borderRadiusValue) borderRadiusValue.textContent = '5px';

    const themeSelect = document.getElementById('themeSelect');
    if (themeSelect) themeSelect.value = 'light';

    // Reset color options
    document.querySelectorAll('.color-option').forEach(option => {
      option.classList.remove('active');
    });

    const defaultColorOption = document.querySelector('.color-option[style*="#4361ee"]');
    if (defaultColorOption) {
      defaultColorOption.classList.add('active');
    }

    NotificationController.show('Styles reset to default', 'success');
  }
};

// Utility Functions
const Utils = {
  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  },

  throttle(func, limit) {
    let inThrottle;
    return function() {
      const args = arguments;
      const context = this;
      if (!inThrottle) {
        func.apply(context, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  },

  formatDate(date) {
    return new Intl.DateTimeFormat('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  },

  formatTime(date) {
    return new Intl.DateTimeFormat('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }).format(date);
  }
};

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  AppController.init();
  NotificationController.init();
});

// Global error handling
window.addEventListener('error', (event) => {
  console.error('Global error:', event.error);
  NotificationController.show('An error occurred. Please refresh the page.', 'warning');
});

// Export controllers for debugging (optional)
if (typeof window !== 'undefined') {
  window.WAD621S = {
    AppController,
    NotificationController,
    TabController,
    NavigationController,
    ClockController,
    CalendarController,
    MoodController,
    ChipController,
    SliderController,
    ThemeController,
    Utils
  };
}